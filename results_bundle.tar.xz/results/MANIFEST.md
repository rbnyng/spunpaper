# Results manifest

Per-seed metrics and analysis outputs behind results used in the manuscript.

| Directory | Desc | Appears in |
|---|---|---|
| `table1_runs/` | 50-seed grid over 3 models x 5 feature sets | Figure 2a, Supplementary Table S14, Note S16 |
| `table1_paired/` | Satellite beats every baseline all CIs excluding zero | Supplementary Table S15, Note S16 |
| `importance_/` | Per-run feature importance by group, per model | Figure 2b |
| `pca_structure/` | per-component environment correlations with bootstrap CIs | Supplementary Tables S3–S5, Note S8 |
| `spatial_cv/` | R2 0.30 under ~2 km realized separation | Methods, Supplementary Table S6, Note S9 |
| `year_ablation/` | Within-year spread 0.0096 vs seed SD 0.0171 | Methods, Supplementary Table S7, Note S10 |
| `patch_size/` | Only 1x1 to 3x3 significant paired ΔR2 past 3x3 is within 1.3 SD | Methods, Supplementary Table S8, Note S11 |
| `spectral_baseline/` | Embeddings +0.0228 R2 over spectral indices, CI [+0.0060, +0.0396], Wilcoxon p = 0.014 | Results, Supplementary Tables S9–S10, Note S12 |
| `continent_transfer/` | Transfer fails in both directions for every feature set | Discussion, Supplementary Table S11, Note S13 |
| `prediction_intervals/` | 90% nominal covers 85.4±1.3% width–error r = +0.470 | Discussion, Supplementary Table S12, Note S14 |
| `error_outliers/` | High-error samples 8.0 vs 87.3 neighbors within 1 km; novelty d = +0.83 | Discussion, Supplementary Table S13, Note S15 |
