"""Does the patch-size effect depend on the embedding year? (interaction test)

The year ablation shows that *overall* skill is invariant to which year's
embeddings you use. The claim that then gets made -- that an ablation run on one
year transfers to any other -- needs one more thing: that the *effect being
ablated* is also year-invariant. Equal skill in two years is compatible with
different sensitivity to patch size, which is an interaction, not a main effect.

This tests it directly on the contrast that matters. 1x1 is a centre crop of the
cached 3x3, so no refetching is needed, and 1x1 -> 3x3 is the step the published
patch-size ablation found significant (the 3x3 -> 5x5 step was not).

Design: the same paired European samples and the same fold seeds in every year,
so the patch-size delta is paired within year, and the years are then compared on
those deltas.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, "src")
from spatial_cv_strategies import RECOMMENDED_LINK_M, distance_group_kfold  # noqa: E402

YEARS = [2022, 2023, 2024]
SEEDS = list(range(1, 11))
N_SPLITS, N_PCA = 5, 16


def load(cache, ids, want):
    X, ok = [], []
    for s in ids:
        f = Path(cache) / f"{s}.npy"
        good = False
        if f.exists():
            a = np.load(f)
            if a.shape == want and np.isfinite(a).all():
                X.append(a.reshape(-1)); good = True
        ok.append(good)
    return np.array(ok), np.asarray(X, np.float32)


def score(X, y, coords, seed):
    """Pooled out-of-fold R2 under grouped CV, PCA refitted inside each fold."""
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import r2_score
    import lightgbm as lgb
    from spun_train_patch import lgbm_fit
    pred = np.full(len(y), np.nan)
    for tr, te in distance_group_kfold(coords, RECOMMENDED_LINK_M, N_SPLITS, seed):
        sc = StandardScaler().fit(X[tr])
        pca = PCA(n_components=min(N_PCA, X.shape[1]), random_state=seed).fit(sc.transform(X[tr]))
        Ztr, Zte = pca.transform(sc.transform(X[tr])), pca.transform(sc.transform(X[te]))
        itr, iva = tr[: int(0.875 * len(tr))], tr[int(0.875 * len(tr)):]
        m = lgb.LGBMRegressor(random_state=seed, n_estimators=1000, learning_rate=0.05,
                              n_jobs=-1, verbose=-1)
        lgbm_fit(m, Ztr[: len(itr)], y[itr], eval_X=Ztr[len(itr):], eval_y=y[iva],
                 stopping_rounds=15)
        pred[te] = m.predict(Zte)
    return float(r2_score(y, pred))


df = pd.read_csv("target_eu.csv")
df["sample_id"] = df.sample_id.astype(str)
ids = df.sample_id.tolist()

present, data = {}, {}
for yr in YEARS:
    for size, cache in ((1, f"p1_cache_{yr}"), (3, f"repro_cache_{yr}")):
        ok, X = load(cache, ids, (size, size, 128))
        present[(yr, size)] = ok
        data[(yr, size)] = X

keep = np.logical_and.reduce(list(present.values()))
print(f"samples present in every year x size cell: {keep.sum()}")
sub = df[keep].reset_index(drop=True)
y = sub.rarefied.to_numpy(float)
coords = sub[["latitude", "longitude"]].to_numpy(float)
for k in data:
    pos = np.cumsum(present[k]) - 1
    data[k] = data[k][pos[keep]]

rows = []
for yr in YEARS:
    for seed in SEEDS:
        r1 = score(data[(yr, 1)], y, coords, seed)
        r3 = score(data[(yr, 3)], y, coords, seed)
        rows.append({"year": yr, "seed": seed, "r2_1x1": r1, "r2_3x3": r3,
                     "delta": r3 - r1})
        print(f"  {yr} seed {seed}: 1x1 {r1:+.4f}  3x3 {r3:+.4f}  delta {r3-r1:+.4f}",
              flush=True)

t = pd.DataFrame(rows)
print("\n--- patch-size effect (3x3 minus 1x1) by year ---")
g = t.groupby("year")["delta"].agg(["mean", "std"])
print(g.round(4).to_string())
d = [t[t.year == yr].delta.values for yr in YEARS]
F, p = stats.f_oneway(*d)
print(f"\nyear x patch-size interaction: F = {F:.3f}, p = {p:.3f}")
print(f"spread of the effect across years = {g['mean'].max() - g['mean'].min():.4f}")
print(f"seed-to-seed SD of the effect within a year = {t.groupby('year').delta.std().mean():.4f}")
t.to_csv("patchsize_year_interaction.csv", index=False)
print("\nwrote patchsize_year_interaction.csv")
